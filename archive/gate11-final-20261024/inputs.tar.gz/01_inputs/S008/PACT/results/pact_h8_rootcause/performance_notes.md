# Performance notes

Repository commit: `9d9103027918b1d4af2b209e6d36133ad82d4a4e`. Timestamp: `2026-10-03T04:23:18.967671+00:00`. Model: `candidate_stateful/depth=3/baseline=9d910302`. Source evidence hashes and invocations: [evidence_manifest.json](evidence_manifest.json), [evidence_index.json](evidence_index.json).

This milestone changes no solver behavior or model semantics.

| Design | Stateful propagation s | Spatial updates s | Rollback s |
|---|---:|---:|---:|
| s9234 | 2.179993 | 77.544658 | 75.393344 |
| s15850 | 1.463165 | 83.116781 | 70.506635 |
| s5378 | 3.985234 | 74.146757 | 73.133488 |

These are existing recorded profiles, not new benchmarks. update_field scans the full cycle vector for each changed net; rollback repeats field subtraction/addition and score performs reductions. They dominate Boolean evaluation. Diagnostic decomposition accumulates into shared cycle×bin arrays and uses a one-cycle slice for per-net peak attribution; it does not allocate a full field for each net. Report-only C controls re-read compact count arrays to avoid rerunning the model. No runtime optimization campaign or solver edit was performed.
