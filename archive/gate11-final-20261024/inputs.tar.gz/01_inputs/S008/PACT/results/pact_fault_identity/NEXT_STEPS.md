# Minimum fault-identity extraction path

Repository commit: `9d9103027918b1d4af2b209e6d36133ad82d4a4e`. Timestamp: `2026-10-03T04:23:18.967671+00:00`. Model: `candidate_stateful/depth=3/baseline=9d910302`. Source evidence hashes and invocations: [evidence_manifest.json](../pact_h8_rootcause/evidence_manifest.json), [evidence_index.json](../pact_h8_rootcause/evidence_index.json).

Scope: independent of H8. Existing coverage/count matches do not prove detected-fault identity sets. No ATPG regeneration or new FAN execution was performed.

For each design use reports/end_to_end/<design>/integration_v1/fault_replay/detected_fault_probe.script, original.script, remapped.script, recorded execution/logs and result.json. Original patterns are artifacts/raw/tool_qualification/fan_atpg/patterns/FAN_<design>.pat; remapped states were independently recovered to integration_v1/patterns_recovered.pat. Preserve executable/library/netlist/pattern hashes from result.json.

1. Reproduce the existing reporter failure with the saved probe script using the already qualified FAN binary (`fan -f <saved-probe.script>`). It reads patterns and runs single-frame stuck-at fault simulation; do not invoke run_atpg or generate patterns. Keep this reproduction separate from successful simulation/statistics.
2. Inspect the detailed reporter around negative/sentinel gate IDs and library pin lookup. The saved diagnosis records a dereference before a negative-ID check. The minimum fix/extraction is a stable detected-fault export after run_fault_sim, using the same fault universe and stable original functional gate/pin plus SA0/SA1 identity. Do not compare transient array indices or collapse conventions from different runs. Validate complete export size against the recorded DT count, reject duplicate or unresolvable identities and preserve raw status/universe mapping.
3. Run the same extraction for original.script and remapped.script, reading the existing original and recovered patterns on the same original functional circuit/library. Independently parse and compare the canonical sets (src/pact/integration/faults.py already contains parse_fault_report/replay_faults but currently leaves sets null when the reporter crashes).

```text
lost_faults = original_detected - remapped_detected
unexpected_faults = remapped_detected - original_detected
```

Export both complete identity sets and sorted differences with command/commit/tool/input hashes. A PASS requires complete successful exports and both differences empty; failed or partial lists remain unknown, never empty. This is a minimum next-step note, not a claimed repair or completed set-equivalence check.
